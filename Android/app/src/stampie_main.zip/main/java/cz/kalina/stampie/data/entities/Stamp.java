package cz.kalina.stampie.data.entities;

public class Stamp extends BaseEntity {
}
