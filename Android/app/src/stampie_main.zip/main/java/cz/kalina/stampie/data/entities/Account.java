package cz.kalina.stampie.data.entities;

public class Account extends BaseEntity {
}
