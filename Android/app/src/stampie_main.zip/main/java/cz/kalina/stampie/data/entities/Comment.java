package cz.kalina.stampie.data.entities;

public class Comment extends BaseEntity {
}
