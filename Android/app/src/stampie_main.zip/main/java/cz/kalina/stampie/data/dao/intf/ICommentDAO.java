package cz.kalina.stampie.data.dao.intf;

public interface ICommentDAO extends IGenericDAO {
}
