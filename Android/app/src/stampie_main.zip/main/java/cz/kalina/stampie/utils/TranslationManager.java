package cz.kalina.stampie.utils;

public class TranslationManager {
}
