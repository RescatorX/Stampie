package cz.kalina.stampie.data.dao.intf;

public interface IAccountDAO extends IGenericDAO {
}
