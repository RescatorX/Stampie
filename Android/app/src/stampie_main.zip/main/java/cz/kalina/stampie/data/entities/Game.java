package cz.kalina.stampie.data.entities;

public class Game extends BaseEntity {
}
