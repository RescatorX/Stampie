package cz.kalina.stampie.utils;

public class NotificationReceiver {
}
