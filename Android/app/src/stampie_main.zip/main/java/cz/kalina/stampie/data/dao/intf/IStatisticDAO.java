package cz.kalina.stampie.data.dao.intf;

public interface IStatisticDAO extends IGenericDAO {
}
