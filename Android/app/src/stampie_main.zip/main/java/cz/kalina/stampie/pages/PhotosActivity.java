package cz.kalina.stampie.pages;

import android.support.v4.app.FragmentActivity;

public class PhotosActivity extends FragmentActivity {
}
