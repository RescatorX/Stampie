package cz.kalina.stampie.pages;

import android.support.v4.app.FragmentActivity;

public class MapStampDetailActivity extends FragmentActivity {
}
