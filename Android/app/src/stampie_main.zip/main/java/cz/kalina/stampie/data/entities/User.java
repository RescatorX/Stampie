package cz.kalina.stampie.data.entities;

public class User extends BaseEntity {
}
