package cz.kalina.stampie.data.dao.intf;

public interface IUserDAO extends IGenericDAO {
}
