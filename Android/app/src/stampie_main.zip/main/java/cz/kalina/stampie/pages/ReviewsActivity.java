package cz.kalina.stampie.pages;

import android.support.v4.app.FragmentActivity;

public class ReviewsActivity extends FragmentActivity {
}
