package cz.kalina.stampie.data.dao.intf;

public interface IStampDAO extends IGenericDAO {
}
