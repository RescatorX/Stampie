package cz.kalina.stampie.data.entities;

public class Photo extends BaseEntity {
}
