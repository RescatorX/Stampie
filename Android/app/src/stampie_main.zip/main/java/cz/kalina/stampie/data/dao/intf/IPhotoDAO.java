package cz.kalina.stampie.data.dao.intf;

public interface IPhotoDAO extends IGenericDAO {
}
