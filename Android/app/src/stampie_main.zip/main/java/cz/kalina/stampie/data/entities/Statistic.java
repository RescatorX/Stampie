package cz.kalina.stampie.data.entities;

public class Statistic extends BaseEntity {
}
